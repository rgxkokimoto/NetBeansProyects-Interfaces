/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXML2.java to edit this template
 */
package gestionseries;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ListView;
import javafx.stage.Stage;

/**
 *
 * @author Alejandro
 */
public class GestionSeriesController implements Initializable {
    
   
    @FXML
    private Button btnAniadirSerie;
    @FXML
    private Button btnModificarSerie;
    @FXML
    private Button btnModificarSerie1;
    
    @FXML
    private ListView<String> seriesListView;
    private ObservableList<String> observableTaskList;
    private final String RUTA_SERIES = "src\\gestionseries\\files\\series.txt";
    
    
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // al iniciar la aplicacion ya deben verse la lista 
       observableTaskList = FXCollections.observableArrayList();
       cargarSeries();
       
       seriesListView.setItems(observableTaskList);
    }    

    @FXML
    private void handleButtonAddSerie(ActionEvent event) {
        Parent root;
        try {
            root = FXMLLoader.load(getClass().getResource("DetalleSerie_1.fxml"));
             Scene scene = new Scene(root);
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            stage.setScene(scene);
            stage.show();
        } catch (IOException ex) {
            Logger.getLogger(GestionSeriesController.class.getName()).log(Level.SEVERE, null, ex);
        }
       
        
    }

    @FXML
    private void handleActionMod(ActionEvent event) {
        String selctSerie = seriesListView.getSelectionModel().getSelectedItem();
        
        // necesito el id de la tarea selecionada.
        
        
        if (selctSerie != null) {
            try {
                // moverse con ides cargados
                String line[] = selctSerie.split("-");
                String id = line[0];
                SerieSelecionada.getIntance().setIdSerie(line[0]);
                
                Parent root = FXMLLoader.load(getClass().getResource("DetalleSerie.fxml"));
                Scene scene = new Scene(root);
                Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
                stage.setScene(scene);
                stage.show();
            } catch (IOException ex) {
                Logger.getLogger(GestionSeriesController.class.getName()).log(Level.SEVERE, null, ex);
            }

        }
        
    }

    @FXML
    private void handleActionExit(ActionEvent event) {
        System.exit(0);
    }

    private void cargarSeries() {
        try(BufferedReader br = new BufferedReader(new FileReader(RUTA_SERIES))){
            
            String line; 
            String[] serieCut;
            while ((line = br.readLine()) != null) {
                serieCut = line.split(",");
                observableTaskList.add(serieCut[0] + "-" + serieCut[1] + "-" + serieCut[2]);
            }
            
        } catch (FileNotFoundException ex) {
            Logger.getLogger(GestionSeriesController.class.getName()).log(Level.SEVERE, null, ex);
            System.out.println("No se pudo encontrar el archivo o ruta: " + RUTA_SERIES);
    
        } catch (IOException ex) {
            Logger.getLogger(GestionSeriesController.class.getName()).log(Level.SEVERE, null, ex);
            System.err.println("Hubo un problema al abrir el archivo de: " + RUTA_SERIES );
        }
    }
    
}
