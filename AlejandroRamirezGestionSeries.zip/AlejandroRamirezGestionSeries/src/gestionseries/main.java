package gestionseries;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXMain.java to edit this template
 */

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

/**
 *
 * @author Alejandro
 */
public class main extends Application {
    
    @Override
    public void start(Stage stage)throws Exception {
         Parent root = FXMLLoader.load(getClass().getResource("GestionSeries.fxml"));
        //asignar a root la CLASE y el recurso de la vista que quieres que se cargue 
        
        Scene scene = new Scene(root); // root se asignara a una instancia de la clase sence 
        
        stage.setScene(scene); // y stage usa un metodo para incluir para poder utilizarla; un lio de 3 pares 
        stage.show();
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }
    
}
